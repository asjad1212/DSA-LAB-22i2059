#include <iostream>
#include <cmath>
using namespace std;

class point {
private:
    int x1;
    int y1;
    int x2;
    int y2;

public:
    point() {
        x1 = 2;
        y1 = 3;
        x2 = 4;
        y2 = 6;
    }

    // getter setters of x1
    void setx1(int xx1) {
        x1 = xx1;
    }

    int getx1() {
        return x1;
    }

    // getter setters of y1
    void sety1(int yy1) {
        y1 = yy1;
    }

    int gety1() {
        return y1;
    }

    // getter setters of x2
    void setx2(int xx2) {
        x2 = xx2;
    }

    int getx2() {
        return x2;
    }

    // getter setters of y2
    void sety2(int yy2) {
        y2 = yy2;
    }

    int gety2() {
        return y2;
    }

    int distance() {
        cout << "distance between two points: ";
        return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
    }
};

int main() {
    point p1;
    int a, b, c, d;
    cout << "enter value of first point : " << endl;
    cin >> a;
    cin >> b;
    p1.setx1(a);
    p1.sety1(b);

    cout << "enter value of second point : " << endl;
    cin >> c;
    cin >> d;
    p1.setx2(c);
    p1.sety2(d);
    cout << p1.distance() << endl;

    return 0;
}
