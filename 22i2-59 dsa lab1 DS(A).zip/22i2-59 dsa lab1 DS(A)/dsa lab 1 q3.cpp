
#include <iostream>
using namespace std;
int main()
{
    int m, n;
    cout << "enter size of rows of a matrix:" << endl;
    cin >> m;
    cout << "enter size of columns of a matrix:" << endl;
    cin >> n;
    int** arr1= new int*[m];
    for (int i = 0; i < m; ++i) {
        arr1[i] = new int[n];
    }

    int enter;
    // menu
    cout << "1. take input for matrix m*n " << endl;
    cout << "2. to display elements of matrix  m*n " << endl;
    cout << "3. sum of elements of matrix  m*n " << endl;
    cout << "4. to display row wise sum of elements matrix m*n" << endl;
    cout << "5. to display column wise sum of matrix m*n" << endl;
    cout << "6. to create transpose of matrix m*n" << endl;

    cout << "enter the number from above:" << endl;
    cin >> enter; 
    switch (enter) {
        // 1... input elements
    case 1:
        void takinginput(int** arr1, int m, int n);
        {
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    cin >> arr1[i][j];

                }
            }
        }

        // 2.... display elements
    case 2:
        void display(int** arr1, int m, int n);
        {
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    cout << arr1[i][j];
                }
            }

        }
        // 3 .... sum elements of array 
    case 3:
        void sum1(int** arr1, int m, int n);
        {
            int sum = 0;
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {

                    sum += arr1[i][j];

                }
            }
        }

        // 4.....row sum

    case 4:
        void sumr(int** arr1, int m, int n);
        {

            for (int i = 0; i < m; i++) {
                int rowsum = 0;
                for (int j = 0; j < n; j++) {

                    rowsum += arr1[i][j];


                    cout << "sum is:" << i + 1 << ": " << rowsum << endl;
                }
            }

        }

        // 5.... column sum
    case 5:
        void sumc(int** arr1, int m, int n);
        {
            int colsum = 0;

            for (int i = 0; i < m; i++) {
                int rowsum = 0;
                for (int j = 0; j < n; j++) {

                    colsum += arr1[i][j];


                    cout << "sum is:" << j + 1 << ": " << colsum << endl;
                }
            }

        }

        //6... transpose

    case 6:
        void transpose(int** arr1, int m, int n);
        {

            for (int j = 0; j < m; j++) {

            
            for (int i = 0; i < n; i++) {
                cout << arr1[i][j] << " " << endl;
            }
            cout << endl;
        }

    }




        }
}


