
#include <iostream>
using namespace std;
int main()
{
        int day, month, year;
        cout << "enter day:" << endl;
        cin >> day;
        cout << "enter month:" << endl;
        cin >> month;
        cout << "enter year:" << endl;
        cin >> year;
        cout << endl;
        cout << "date is: " << day << "/" << month << "/" << year << endl;

    }

}
